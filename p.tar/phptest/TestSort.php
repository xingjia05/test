<?php
$a = [
    "Lua",
        "swift",
            "python",
                "java",
                    "c++",
                ];
sort($a);
print_r($a);
$b = [
    'B','b'
];
sort($b);
print_r($b);
