<?php
$a = 'wqw';
print_r($a);
$b = $a;
xdebug_debug_zval($a);
