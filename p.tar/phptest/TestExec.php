<?php
print_r('sss');die;
$strArr = exec("grep -r test | ../../test/");
print_r($strArr);
