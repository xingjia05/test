<?php
print_r(bindec('1111 1111 1111 1111'));die;
