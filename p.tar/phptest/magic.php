<?php
class person {
    public $name = 'qq';
    
    public function __tostring() {
        return 'name is' . $this->name;
    }
}

$p = new person();
echo $p;